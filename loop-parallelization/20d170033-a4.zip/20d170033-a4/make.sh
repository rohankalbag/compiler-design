javac Main.java -Xlint:unchecked
java Main < Test.java