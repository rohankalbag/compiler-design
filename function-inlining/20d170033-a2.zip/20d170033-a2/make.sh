find . -name "*.class" -type f -delete
javac Main.java