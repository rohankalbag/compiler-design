if [ -d "Adv-Compilers-A1-testcases" ]
then
    rm -rf Adv-Compilers-A1-testcases
fi
git clone https://github.com/Sandeep-Varma/Adv-Compilers-A1-testcases
echo ""
echo "Pulled testcases repo"
javac Main.java
echo ""
echo "Compiled Main.java"
echo ""
while IFS=", " read -r file expected_output
do
    output=$(java Main < Adv-Compilers-A1-testcases/"$file")
    if [ "$output" == "$expected_output" ]
    then
        echo "Testcase $file passed"
    else
        echo "Testcase $file failed"
        echo "Expected output: $expected_output"
        echo "Your output: $output"
    fi
    echo ""
done < Adv-Compilers-A1-testcases/testcases_all.csv
rm -rf Adv-Compilers-A1-testcases
echo "Done"